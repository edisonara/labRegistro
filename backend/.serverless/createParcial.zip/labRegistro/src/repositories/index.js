// Repositorios para interactuar con la base de datos
// Exporta aquí todos los repositorios que se vayan creando

module.exports = {
  // Ejemplo:
  // userRepository: require('./user.repository')
};
