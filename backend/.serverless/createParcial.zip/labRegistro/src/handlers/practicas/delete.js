const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  const parcialId = event.pathParameters.parcialId;
  const practicaId = event.pathParameters.practicaId;

  const params = {
    TableName: 'RegistroAcademico',
    Key: {
      PK: `PARCIAL#${parcialId}`,
      SK: `PRACTICA#${practicaId}`,
    }
  };

  try {
    await db.delete(params).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Práctica eliminada correctamente' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
