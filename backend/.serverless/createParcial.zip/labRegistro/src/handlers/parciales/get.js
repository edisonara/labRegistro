const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  const id = event.pathParameters.id;

  const params = {
    TableName: 'RegistroAcademico',
    Key: {
      PK: `PARCIAL#${id}`,
      SK: 'METADATA'
    }
  };

  try {
    const result = await db.get(params).promise();

    if (!result.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Parcial no encontrado' }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify(result.Item),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
