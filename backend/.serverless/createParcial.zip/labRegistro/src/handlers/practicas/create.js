const AWS = require('aws-sdk');
const uuid = require('uuid');
const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  const data = JSON.parse(event.body);
  const practicaId = uuid.v4();

  if (!data.parcialId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Falta el ID del parcial (parcialId)' }),
    };
  }

  const item = {
    PK: `PARCIAL#${data.parcialId}`,
    SK: `PRACTICA#${practicaId}`,
    nombre: data.nombre,
    nota: data.nota,
    estudiante: data.estudiante
  };

  try {
    await db.put({
      TableName: 'RegistroAcademico',
      Item: item,
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Práctica creada', id: practicaId }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
