const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  const parcialId = event.pathParameters.parcialId;
  const practicaId = event.pathParameters.practicaId;
  const data = JSON.parse(event.body);

  const params = {
    TableName: 'RegistroAcademico',
    Key: {
      PK: `PARCIAL#${parcialId}`,
      SK: `PRACTICA#${practicaId}`,
    },
    UpdateExpression: 'set #n = :n, nota = :nota, estudiante = :e',
    ExpressionAttributeNames: {
      '#n': 'nombre'
    },
    ExpressionAttributeValues: {
      ':n': data.nombre,
      ':nota': data.nota,
      ':e': data.estudiante
    },
    ReturnValues: 'ALL_NEW'
  };

  try {
    const result = await db.update(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(result.Attributes),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
