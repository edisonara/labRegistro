// Utilidades y funciones de ayuda
// Exporta aquí todas las utilidades que se vayan creando

module.exports = {
  // Ejemplo:
  // logger: require('./logger'),
  // constants: require('./constants')
};
