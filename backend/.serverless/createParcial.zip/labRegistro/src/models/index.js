// Modelos de la base de datos
// Exporta aquí todos los modelos que se vayan creando

module.exports = {
  // Ejemplo:
  // User: require('./user.model')
};
