const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');  // Mejor importar así para uuid

const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  try {
    const data = JSON.parse(event.body);

    // Validar campos obligatorios
    if (!data.nombre || !data.fecha || !data.docente) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Faltan datos obligatorios: nombre, fecha o docente' }),
      };
    }

    const id = uuidv4();

    const item = {
      PK: `PARCIAL#${id}`,
      SK: 'METADATA',
      nombre: data.nombre,
      fecha: data.fecha,
      docente: data.docente,
    };

    await db.put({
      TableName: process.env.DYNAMODB_TABLE,
      Item: item,
    }).promise();

    return {
      statusCode: 201,
      body: JSON.stringify({ message: 'Parcial creado', id }),
    };
  } catch (error) {
    console.error('Error en createParcial:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
};
