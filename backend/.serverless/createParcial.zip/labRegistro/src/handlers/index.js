// Manejadores de las rutas de la API
// Exporta aquí todos los controladores que se vayan creando

module.exports = {
  // Ejemplo:
  // userController: require('./user.controller')
};
