// Data Transfer Objects (DTOs) para la aplicación
// Exporta aquí todos los DTOs que se vayan creando

module.exports = {
  // Ejemplo:
  // userDto: require('./user.dto')
};
