// Lógica de negocio de la aplicación
// Exporta aquí todos los servicios que se vayan creando

module.exports = {
  // Ejemplo:
  // userService: require('./user.service')
};
