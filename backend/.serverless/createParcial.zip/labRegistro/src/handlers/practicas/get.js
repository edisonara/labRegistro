const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  const parcialId = event.pathParameters.parcialId;
  const practicaId = event.pathParameters.practicaId;

  const params = {
    TableName: 'RegistroAcademico',
    Key: {
      PK: `PARCIAL#${parcialId}`,
      SK: `PRACTICA#${practicaId}`
    }
  };

  try {
    const result = await db.get(params).promise();

    if (!result.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Práctica no encontrada' }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify(result.Item),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
