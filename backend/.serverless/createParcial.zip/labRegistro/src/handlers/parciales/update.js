const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();

module.exports.handler = async (event) => {
  const id = event.pathParameters.id;
  const data = JSON.parse(event.body);

  const params = {
    TableName: 'RegistroAcademico',
    Key: {
      PK: `PARCIAL#${id}`,
      SK: 'METADATA',
    },
    UpdateExpression: 'set #n = :n, fecha = :f, docente = :d',
    ExpressionAttributeNames: {
      '#n': 'nombre'
    },
    ExpressionAttributeValues: {
      ':n': data.nombre,
      ':f': data.fecha,
      ':d': data.docente
    },
    ReturnValues: 'ALL_NEW'
  };

  try {
    const result = await db.update(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(result.Attributes),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
